import {chromium} from 'playwright';import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1280,height:950}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.played=[];window.mediaErrors=[];const NativeAudio=window.Audio;window.Audio=new Proxy(NativeAudio,{construct(target,args){const a=Reflect.construct(target,args);a.addEventListener('playing',()=>window.played.push(a.src));a.addEventListener('error',()=>window.mediaErrors.push(a.src));return a;}});Object.defineProperty(window,'speechSynthesis',{get(){throw Error('System TTS must not be used');}});});
 await page.goto('http://localhost:4173');await page.waitForFunction(()=>window.liftStudio?.modelReady,null,{timeout:90000});await page.evaluate(()=>window.liftStudio.view.renderer.setPixelRatio(.5));
 await page.locator('#sound').click();await page.waitForFunction(()=>window.played.some(s=>s.endsWith('welcome-en.mp3')),null,{timeout:30000});await page.waitForFunction(()=>window.liftStudio.announcer.active===null);
 await page.getByRole('button',{name:'2층 목적지',exact:true}).click();await page.waitForFunction(()=>window.played.some(s=>s.endsWith('up-en.mp3')),null,{timeout:30000});await page.waitForFunction(()=>window.liftStudio.announcer.active===null);
 await page.evaluate(()=>{const {controller:c,announcer:a}=window.liftStudio;for(let i=0;i<1800&&c.state!=='opening';i++){c.tick(1/60);a.observe(c);}});
 await page.waitForFunction(()=>window.played.some(s=>s.endsWith('opening-en.mp3')),null,{timeout:30000});
 const played=await page.evaluate(()=>window.played.map(s=>s.split('/').at(-1)));assert.deepEqual(played.slice(-4),['floor-2-ko.mp3','floor-2-en.mp3','opening-ko.mp3','opening-en.mp3']);
 await page.locator('#voice-volume').fill('30');assert.equal(await page.evaluate(()=>window.liftStudio.announcer.synth.current?.volume),.3);
 await page.screenshot({path:'../outputs/Recorded_Voice_Guide.png',fullPage:true});await page.locator('#sound').click();assert.equal(await page.evaluate(()=>window.liftStudio.announcer.synth.current),null);
 assert.deepEqual(await page.evaluate(()=>window.mediaErrors),[]);assert.deepEqual(errors,[]);console.log('PASS: actual MP3 playback KO→EN, direction, floor→opening sequence, live volume and mute; system TTS blocked; no media/page errors.');
}finally{await browser.close();}
