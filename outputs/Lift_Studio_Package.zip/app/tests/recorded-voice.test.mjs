import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import {RecordedVoice,RecordedUtterance} from '../src/recorded-voice.js';
import {VOICE_CLIPS as clips} from '../src/voice-catalog.js';
const made=[];class Audio {constructor(src){this.src=src;made.push(this);}play(){return Promise.resolve();}pause(){this.paused=true;}removeAttribute(){this.src='';}load(){}}
test('all 42 prompts resolve to fixed files, without system voices',()=>{const voice=new RecordedVoice({clips,AudioClass:Audio});for(const c of clips){const u=new RecordedUtterance(c.text);u.lang=c.lang;voice.speak(u);assert.equal(made.at(-1).src,'./assets/voice/'+c.file);}voice.cancel();});
test('cancel stops the file and ignores previous completion callbacks',()=>{const voice=new RecordedVoice({clips,AudioClass:Audio});const u=new RecordedUtterance(clips[0].text);u.lang=clips[0].lang;let ended=0;u.onend=()=>ended++;voice.speak(u);const a=made.at(-1),stale=a.onended;voice.cancel();stale();assert.equal(ended,0);assert.equal(a.paused,true);});
test('missing recording produces an error, never a system TTS fallback',async()=>{const voice=new RecordedVoice({clips,AudioClass:Audio});const u=new RecordedUtterance('missing');let error;u.onerror=e=>error=e.error;voice.speak(u);await Promise.resolve();assert.equal(error,'missing-recording');});
