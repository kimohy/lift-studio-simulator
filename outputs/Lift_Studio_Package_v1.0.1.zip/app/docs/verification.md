# Verification
- 21 controller tests: 15 stops, duplicate suppression, collective dispatch, door interlock, reopen on obstruction, same-floor calls, endpoint input guards, alarm, pause/reset, braking-safe inserted stops, turnaround direction commitment, bounded acceleration and all-floor queue drain.
- GLB geometry: 32 moving door panels (2 car + 30 landing), 15 landings, native car/counterweight/controller nodes.
- Independent review found and repaired: final velocity snap, down-call turnaround direction, basement counterweight position.
- Controller neutral counterweight offset is -16.5m from original geometry. Suspension top at 1F is 15.75m, leaving 19.15m cable length; endpoints remain inside the shaft.
- Browser smoke: actual GLB loading, open/close, movement to 2F, moving door rejection, obstruction hold, alarm, view presets, mobile overflow; endpoint rope lengths and counterweight bounds.

## 1.0.1 — Hall-call turnaround fix
- Reproduced the reported 9F up + B1 down loop in 1.0.0: both calls remained after seven alternating stops in 200 simulated seconds.
- Arrival now clears served calls using the incoming direction before committing a turnaround. Matching hall pickups retain their boarding direction during dwell.
- Regression checks cover both input orders, 60 seconds of stable idle after clearing, all 756 ordered pairs of valid hall calls from 1F, and a 9F up pickup followed by a new 10F destination.
