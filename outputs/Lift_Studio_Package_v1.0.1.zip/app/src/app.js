import {LiftController,FLOORS} from './controller.js';
import {LiftScene} from './scene.js';
const $=id=>document.getElementById(id);
const controller=new LiftController();let view,rate=1,sound=false,audioContext,lastStops=0;
const names={idle:'대기 중',moving:'운행 중',opening:'문 여는 중',open:'문 열림',closing:'문 닫는 중'};
const clock=t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${String(Math.floor(t%60)).padStart(2,'0')}`;
function say(text){$('control-hint').textContent=text;}
function beep(){if(!sound||!audioContext)return;const t=audioContext.currentTime;[880,659.25].forEach((hz,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain();osc.type='sine';osc.frequency.value=hz;gain.gain.setValueAtTime(0,t+i*.22);gain.gain.linearRampToValueAtTime(.12,t+i*.22+.015);gain.gain.exponentialRampToValueAtTime(.001,t+i*.22+.65);osc.connect(gain);gain.connect(audioContext.destination);osc.start(t+i*.22);osc.stop(t+i*.22+.7);});}
function act(action,floor,direction){
  if(action==='car'){controller.callCar(floor);say(`${FLOORS[floor]}층 목적지가 등록되었습니다.`);}
  if(action==='hall'){controller.callHall(floor,direction);say(`${FLOORS[floor]}층 ${direction===1?'상행':'하행'} 호출이 등록되었습니다.`);}
  if(action==='open'){say(controller.openDoor()?'문을 열고 대기 시간을 연장합니다.':'운행 중에는 문을 열 수 없습니다.');}
  if(action==='close'){say(controller.closeDoor()?'문을 닫습니다.':controller.obstruction?'감지선이 차단되어 문을 닫을 수 없습니다.':'문이 열려 있을 때 사용할 수 있습니다.');}
  if(action==='alarm'){controller.toggleAlarm();say(controller.alarm?'비상 호출 신호를 표시합니다. 실제 통화는 연결되지 않습니다.':'비상 호출 신호를 해제했습니다.');}
  updateUI();
}
const rowButtons=[];const carButtons=[];
for(let i=14;i>=0;i--){
  const row=document.createElement('div');row.className='floor-row'+(i<5?' basement':'');row.dataset.floor=i;
  row.innerHTML=`<span class="floor-name">${FLOORS[i]}<small>F</small></span><span class="floor-track"><span class="car-marker"></span></span><div class="hall-controls"></div>`;
  for(const dir of [1,-1]){const b=document.createElement('button');b.textContent=dir===1?'▲':'▼';b.disabled=(dir===1&&i===14)||(dir===-1&&i===0);b.setAttribute('aria-label',`${FLOORS[i]}층 ${dir===1?'상행':'하행'} 호출`);b.setAttribute('aria-pressed','false');b.addEventListener('click',()=>act('hall',i,dir));row.querySelector('.hall-controls').append(b);rowButtons.push({b,i,dir});}
  $('floor-list').append(row);
}
for(const i of [12,13,14,9,10,11,6,7,8,3,4,5,0,1,2]){
  const b=document.createElement('button');b.textContent=FLOORS[i];b.dataset.carFloor=i;b.className=i===5?'home':'';b.setAttribute('aria-label',`${FLOORS[i]}층 목적지`);b.setAttribute('aria-pressed','false');b.addEventListener('click',()=>act('car',i));$('car-buttons').append(b);carButtons.push({b,i});
}
$('open-door').onclick=()=>act('open');$('close-door').onclick=()=>act('close');$('alarm').onclick=()=>act('alarm');
$('obstruction').onclick=()=>{controller.setObstruction(!controller.obstruction);say(controller.obstruction?'감지선을 차단했습니다. 문이 닫히면 다시 열립니다.':'감지선이 복구되었습니다. 3초 후 문이 닫힙니다.');updateUI();};
$('pause').onclick=()=>{controller.paused=!controller.paused;updateUI();};
$('time-scale').onchange=e=>{rate=Number(e.target.value);};
$('sound').onclick=async()=>{sound=!sound;if(sound){audioContext??=new AudioContext();await audioContext.resume();beep();}$('sound').textContent=sound?'소리 켜짐':'소리 꺼짐';$('sound').setAttribute('aria-pressed',String(sound));};
$('reset').onclick=()=>{controller.reset();lastStops=0;rate=1;$('time-scale').value='1';if(view)view.setView(view.view,controller);say('1층 대기 상태로 초기화했습니다.');updateUI();};
const captions={lobby:'승강장 · 카 위치 따라가기',cabin:'탑승 시점 · 내부 버튼 직접 조작',shaft:'B5—10F · 승강로와 균형추',controller:'제어반 · 운행 상태 실시간 연동'};
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>{for(const btn of document.querySelectorAll('[data-view]')){btn.classList.toggle('selected',btn===b);btn.setAttribute('aria-pressed',String(btn===b));}view?.setView(b.dataset.view,controller);$('view-caption').textContent=captions[b.dataset.view];};
let queueKey='',eventKey='';
function setText(id,value){const el=$(id);if(el.textContent!==value)el.textContent=value;}
function updateUI(){
  const c=controller;const arrow=c.direction===1?'↑':c.direction===-1?'↓':'—';
  setText('big-floor',FLOORS[c.floor]);setText('panel-floor',FLOORS[c.floor]);setText('big-direction',arrow);setText('panel-direction',arrow);
  setText('state-badge',c.paused?'일시정지':names[c.state]);$('state-badge').classList.toggle('moving',c.state==='moving');
  setText('panel-state',c.alarm?'ALARM':c.paused?'PAUSED':c.state==='moving'?(c.direction>0?'GOING UP':'GOING DOWN'):c.state==='idle'?'READY':c.state.toUpperCase());
  $('speed-value').innerHTML=`${Math.abs(c.velocity).toFixed(2)} <small>m/s</small>`;
  setText('target-value',c.target!==null?FLOORS[c.target]+'F':'—');
  setText('door-value',c.door===0?'닫힘':c.door===1?'열림':`${Math.round(c.door*100)}%`);
  setText('interlock',c.door===0?'잠금':'해제');setText('drive',c.state==='moving'?(c.direction>0?'상행 구동':'하행 구동'):'대기');setText('brake',c.state==='moving'?'해제':'체결');setText('sensor',c.obstruction?'차단 감지':'정상');setText('logic-state',c.state.toUpperCase());
  $('sensor').classList.toggle('warn',c.obstruction);$('interlock').classList.toggle('warn',c.door>0);
  $('controller-led').style.background=c.alarm?'var(--red)':'var(--cyan)';
  $('pause').textContent=c.paused?'▶':'Ⅱ';$('pause').setAttribute('aria-pressed',String(c.paused));$('pause').setAttribute('aria-label',c.paused?'시뮬레이션 재생':'시뮬레이션 일시정지');document.body.classList.toggle('paused',c.paused);
  for(const {b,i} of carButtons){const active=c.car.has(i);b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));}
  for(const {b,i,dir} of rowButtons){const active=(dir===1?c.up:c.down).has(i);b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));}
  for(const row of document.querySelectorAll('.floor-row'))row.classList.toggle('current',+row.dataset.floor===c.floor);
  for(const [id,on] of [['obstruction',c.obstruction],['alarm',c.alarm]]){$(id).classList.toggle('active',on);$(id).setAttribute('aria-pressed',String(on));}
  const pending=c.pending();const q=pending.map(n=>`${n}:${c.car.has(n)}:${c.up.has(n)}:${c.down.has(n)}`).join(',');
  if(queueKey!==q||!$('queue').children.length){queueKey=q;$('queue').replaceChildren();if(!pending.length){const e=document.createElement('span');e.className='empty';e.textContent='등록된 호출이 없습니다.';$('queue').append(e);}else for(const n of pending){const e=document.createElement('span');e.className='queue-chip';e.textContent=FLOORS[n]+'F'+(c.up.has(n)?' ↑':'')+(c.down.has(n)?' ↓':'');$('queue').append(e);}}
  const ek=c.events.slice(0,3).map(e=>`${e.time}${e.message}`).join('|');
  if(ek!==eventKey){eventKey=ek;$('events').replaceChildren();for(const event of c.events.slice(0,3)){const e=document.createElement('div');e.className='event '+event.type;const t=document.createElement('time');t.textContent=clock(event.time);const text=document.createElement('span');text.textContent=event.message;e.append(t,text);$('events').append(e);}}
  setText('event-clock',clock(c.time));
  if(c.stops.length>lastStops){beep();lastStops=c.stops.length;}
}
try{
  view=new LiftScene($('scene'),act);
  view.load().catch(error=>{console.error(error);$('loading').innerHTML='<strong>3D 모델을 불러오지 못했습니다.</strong><span>페이지를 새로고침해 주세요. 조작반은 계속 사용할 수 있습니다.</span>';});
}catch(error){console.error(error);$('loading').innerHTML='<strong>3D 화면을 시작할 수 없습니다.</strong><span>브라우저의 그래픽 가속을 확인해 주세요.</span>';}
// Public inspection API for the simulator; no external machinery or network control.
window.liftStudio={controller,get view(){return view;},get modelReady(){return !!view?.ready;},version:'1.0.1'};
let last=performance.now(),uiElapsed=0;
function frame(now){const dt=document.hidden?0:Math.min((now-last)/1000,.1);last=now;controller.tick(dt*rate);uiElapsed+=dt;view?.update(controller);view?.render();if(uiElapsed>.08){updateUI();uiElapsed=0;}requestAnimationFrame(frame);}
updateUI();requestAnimationFrame(frame);
