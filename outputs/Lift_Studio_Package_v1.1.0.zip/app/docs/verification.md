# Verification
- 21 controller tests: 15 stops, duplicate suppression, collective dispatch, door interlock, reopen on obstruction, same-floor calls, endpoint input guards, alarm, pause/reset, braking-safe inserted stops, turnaround direction commitment, bounded acceleration and all-floor queue drain.
- GLB geometry: 32 moving door panels (2 car + 30 landing), 15 landings, native car/counterweight/controller nodes.
- Independent review found and repaired: final velocity snap, down-call turnaround direction, basement counterweight position.
- Controller neutral counterweight offset is -16.5m from original geometry. Suspension top at 1F is 15.75m, leaving 19.15m cable length; endpoints remain inside the shaft.
- Browser smoke: actual GLB loading, open/close, movement to 2F, moving door rejection, obstruction hold, alarm, view presets, mobile overflow; endpoint rope lengths and counterweight bounds.

## 1.0.1 — Hall-call turnaround fix
- Reproduced the reported 9F up + B1 down loop in 1.0.0: both calls remained after seven alternating stops in 200 simulated seconds.
- Arrival now clears served calls using the incoming direction before committing a turnaround. Matching hall pickups retain their boarding direction during dwell.
- Regression checks cover both input orders, 60 seconds of stable idle after clearing, all 756 ordered pairs of valid hall calls from 1F, and a 9F up pickup followed by a new 10F destination.

## 1.1.0 — First-person game mode
- All 40 controller/player tests pass, retaining all 756 ordered hall-call pair regressions.
- Player tests cover closed and partly opened doors, absent car, wall/cabin bounds, diagonal speed, large-step collision, boarding/riding/exit, pause, view orientation and safe mode exit.
- Manual and player obstruction sources remain independent. Review found and fixed remote-floor obstruction: waiting against closed landing doors no longer holds a remote elevator open.
- Real Chromium input test passed: WASD against closed doors, physical 1F hall-button click, walking into cabin, physical 2F/3F buttons, ride to 2F, walk out, player stays on 2F while car continues to 3F, blur releases keys and game exit restores OrbitControls.
- No browser page errors in that flow. Software WebGL verification uses half pixel density to accommodate the test environment; screenshots were visually inspected.
