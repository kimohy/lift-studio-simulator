import {WalkingPlayer} from './player.js';
import {FLOORS} from './controller.js';
const $=id=>document.getElementById(id);
export class GameMode {
  constructor(view,controller){
    this.view=view;this.controller=controller;view.game=this;
    this.player=new WalkingPlayer();this.active=false;this.keys=new Set();this.dragging=false;this.hoverTime=0;this.cursor={x:0,y:0};this.previousView='lobby';
    const canvas=view.canvas;
    canvas.tabIndex=0;
    window.addEventListener('keydown',e=>{
      if(!this.active||e.target.closest?.('input,select,textarea,[contenteditable="true"]'))return;
      if(['KeyW','KeyA','KeyS','KeyD'].includes(e.code)){e.preventDefault();this.keys.add(e.code);}
    });
    window.addEventListener('keyup',e=>this.keys.delete(e.code));
    window.addEventListener('blur',()=>this.clearInput());
    document.addEventListener('visibilitychange',()=>{if(document.hidden)this.clearInput();});
    document.addEventListener('pointerlockchange',()=>{this.clearInput();document.body.classList.toggle('pointer-locked',document.pointerLockElement===canvas);$('game-lock').textContent=document.pointerLockElement===canvas?'마우스 해제 (Esc)':'마우스 고정';});
    canvas.addEventListener('contextmenu',e=>{if(this.active)e.preventDefault();});
    canvas.addEventListener('pointerdown',e=>{
      if(!this.active)return;canvas.focus({preventScroll:true});
      if(e.button===2){this.dragging=true;canvas.setPointerCapture(e.pointerId);}
    });
    canvas.addEventListener('pointerup',e=>{if(e.button===2){this.dragging=false;if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);}});
    canvas.addEventListener('pointercancel',()=>this.clearInput());
    canvas.addEventListener('pointermove',e=>{
      if(!this.active)return;
      const rect=canvas.getBoundingClientRect();this.cursor={x:(e.clientX-rect.left)/rect.width*2-1,y:-(e.clientY-rect.top)/rect.height*2+1};
      if(this.dragging||document.pointerLockElement===canvas){this.player.look(e.movementX,e.movementY);this.applyCamera();}
    });
    canvas.addEventListener('wheel',e=>{if(this.active)e.preventDefault();},{passive:false});
    $('game-toggle').addEventListener('click',()=>this.active?this.exit():this.enter());
    $('game-exit').addEventListener('click',()=>this.exit());
    $('game-lock').addEventListener('click',()=>{
      if(document.pointerLockElement===canvas){document.exitPointerLock();return;}
      try{Promise.resolve(canvas.requestPointerLock()).catch(()=>this.message('마우스 오른쪽 버튼을 누른 채 움직이면 시점을 바꿀 수 있습니다.'));}catch{this.message('오른쪽 드래그로 시점을 바꿀 수 있습니다.');}
    });
  }
  clearInput(){this.keys.clear();this.dragging=false;}
  message(text){$('game-target').textContent=text;this.messageUntil=performance.now()+2200;}
  enter(){
    if(!this.view.ready)return;
    this.previousView=this.view.view==='game'?'lobby':this.view.view;this.active=true;this.clearInput();this.player.sync(this.controller);
    document.body.classList.add('game-active');$('game-hud').hidden=false;$('game-toggle').textContent='시뮬레이터로 돌아가기';$('game-toggle').setAttribute('aria-pressed','true');
    $('time-scale').value='1';$('time-scale').dispatchEvent(new Event('change'));$('time-scale').disabled=true;
    this.view.setView('game',this.controller);this.applyCamera();this.view.canvas.focus({preventScroll:true});this.view.resize();
    this.message('WASD로 걸어가서 승강장 버튼을 클릭하세요.');this.updateHUD();
  }
  exit(){
    if(!this.active)return;
    this.player.leaveDoorway();this.controller.setObstruction(false,'player');this.active=false;this.clearInput();
    if(document.pointerLockElement===this.view.canvas)document.exitPointerLock();
    document.body.classList.remove('game-active','pointer-locked');$('game-hud').hidden=true;$('game-toggle').textContent='게임 모드';$('game-toggle').setAttribute('aria-pressed','false');$('time-scale').disabled=false;
    this.view.setView(this.previousView,this.controller);this.view.canvas.style.cursor='';this.view.resize();
  }
  reset(){
    this.player.reset();this.clearInput();this.controller.setObstruction(false,'player');
    if(document.pointerLockElement===this.view.canvas)document.exitPointerLock();
    if(this.active){this.view.setView('game',this.controller);this.applyCamera();this.updateHUD();}
  }
  beforeStep(){if(this.active){this.player.sync(this.controller);this.controller.setObstruction(this.player.blocksDoor(this.controller),'player');}}
  update(dt){
    if(!this.active)return;
    const forward=Number(this.keys.has('KeyW'))-Number(this.keys.has('KeyS'));
    const strafe=Number(this.keys.has('KeyD'))-Number(this.keys.has('KeyA'));
    this.player.move(forward,strafe,dt,this.controller);
    this.controller.setObstruction(this.player.blocksDoor(this.controller),'player');this.applyCamera();
    this.hoverTime+=dt;
    if(this.hoverTime>.10){this.hoverTime=0;this.updateHUD();}
  }
  applyCamera(){
    const p=this.player;this.view.camera.position.set(p.x,p.eyeY(this.controller),p.z);
    this.view.camera.rotation.order='YXZ';this.view.camera.rotation.set(p.pitch,p.yaw,0);this.view.camera.updateMatrixWorld();
  }
  accepts(data){
    if(!this.active)return true;
    if(data.action==='hall')return this.player.zone==='lobby'&&data.floorIndex===this.player.floor;
    return this.player.zone==='cabin';
  }
  updateHUD(){
    const p=this.player,c=this.controller;
    $('player-location').textContent=p.zone==='cabin'?`엘리베이터 안 · ${FLOORS[c.floor]}층${c.state==='moving'?' 이동 중':''}`:`${FLOORS[p.floor]}층 승강장`;
    $('game-lift-state').textContent=`엘리베이터 ${FLOORS[c.floor]}층 · ${c.state==='moving'?(c.direction>0?'올라가는 중':'내려가는 중'):c.door>0?'문 열림':'대기'}`;
    const ndc=document.pointerLockElement===this.view.canvas?{x:0,y:0}:this.cursor;
    const hit=this.view.getInteraction(ndc,1.8);
    this.view.canvas.style.cursor=hit?'pointer':this.dragging?'grabbing':'crosshair';
    $('game-crosshair').classList.toggle('targeted',!!hit);
    if(performance.now()<(this.messageUntil||0))return;
    let text;
    if(hit){const d=hit.userData;text=d.action==='hall'?`${FLOORS[d.floorIndex]}층 ${d.direction===1?'올라가기':'내려가기'} 호출 · 왼쪽 클릭`:d.action==='car'?`${FLOORS[d.floorIndex]}층 선택 · 왼쪽 클릭`:({'open':'문 열림','close':'문 닫힘','alarm':'비상 호출'}[d.action]+' · 왼쪽 클릭');}
    else if(p.inDoorway())text='출입문을 지나 안쪽이나 승강장으로 이동하세요.';
    else if(p.zone==='cabin')text=c.state==='moving'?'이동 중입니다. 도착해 문이 열리면 걸어서 내리세요.':'내부 층 버튼을 클릭해 목적층을 선택하세요.';
    else text='호출 버튼에 다가가 클릭하고, 문이 열리면 걸어서 타세요.';
    $('game-target').textContent=text;
  }
}
