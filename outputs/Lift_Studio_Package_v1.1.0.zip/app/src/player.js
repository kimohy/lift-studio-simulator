export class WalkingPlayer {
  constructor(){this.reset();}
  reset(){this.x=0;this.z=2.65;this.floor=5;this.zone='lobby';this.yaw=0;this.pitch=-.12;this.speed=2;}
  eyeY(c){return (this.zone==='cabin'?c.position-17.5:(this.floor-5)*3.5)+1.65;}
  sync(c){if(this.zone==='cabin')this.floor=c.floor;}
  look(dx,dy){this.yaw-=dx*.0025;this.pitch=Math.max(-1.3,Math.min(1.3,this.pitch-dy*.0025));}
  inDoorway(){return Math.abs(this.x)<.45&&this.z>.60&&this.z<1.40;}
  blocksDoor(c){return this.inDoorway()&&c.aligned()&&c.floor===this.floor;}
  leaveDoorway(){if(this.inDoorway())this.z=this.zone==='cabin'?.48:1.62;}
  canOccupy(x,z,c){
    const aligned=c.aligned()&&c.floor===this.floor;
    if(Math.abs(x)<=2.28&&z>=1.40&&z<=3.42)return this.zone==='lobby'||aligned;
    if(Math.abs(x)<=.70&&z>=-.62&&z<=.66)return this.zone==='cabin'||aligned;
    return Math.abs(x)<=.25&&z>=.66&&z<=1.40&&aligned&&c.door>=.95;
  }
  move(forward,strafe,dt,c){
    this.sync(c);
    if(c.paused||!Number.isFinite(dt)||dt<=0)return;
    const norm=Math.hypot(forward,strafe);if(!norm)return;
    forward/=Math.max(1,norm);strafe/=Math.max(1,norm);
    const distance=this.speed*Math.min(dt,.25);
    const dx=(strafe*Math.cos(this.yaw)-forward*Math.sin(this.yaw))*distance;
    const dz=(-forward*Math.cos(this.yaw)-strafe*Math.sin(this.yaw))*distance;
    const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.035));
    for(let i=0;i<steps;i++){
      const nx=this.x+dx/steps;if(this.canOccupy(nx,this.z,c))this.x=nx;
      const nz=this.z+dz/steps;if(this.canOccupy(this.x,nz,c))this.z=nz;
      if(this.z<=.66)this.zone='cabin';
      else if(this.z>=1.40){if(this.zone==='cabin')this.floor=c.floor;this.zone='lobby';}
    }
    this.sync(c);
  }
}
