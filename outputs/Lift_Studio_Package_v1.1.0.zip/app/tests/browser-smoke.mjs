import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1440,height:1050},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
await page.goto('http://localhost:4173/');await page.waitForFunction(()=>window.liftStudio?.modelReady,null,{timeout:60000});
await page.screenshot({path:'../outputs/App_Desktop.png',fullPage:true});
await page.locator('#open-door').click();await page.waitForFunction(()=>window.liftStudio.controller.state==='open');
await page.screenshot({path:'../outputs/App_Lobby_Open.png',fullPage:true});
await page.locator('[data-view="cabin"]').click();await page.locator('#pause').click();await page.waitForTimeout(300);await page.screenshot({path:'../outputs/App_Cabin.png',fullPage:true});
await page.locator('[data-view="controller"]').click();await page.waitForTimeout(300);await page.screenshot({path:'../outputs/App_Controller.png',fullPage:true});
await page.locator('[data-view="shaft"]').click();await page.waitForTimeout(300);await page.screenshot({path:'../outputs/App_Shaft.png',fullPage:true});
await page.locator('#reset').click();await page.locator('#time-scale').selectOption('4');await page.getByRole('button',{name:'2층 목적지',exact:true}).click();
await page.waitForFunction(()=>window.liftStudio.controller.state==='moving');await page.locator('#open-door').click();assert.equal(await page.evaluate(()=>window.liftStudio.controller.door),0);
await page.waitForFunction(()=>window.liftStudio.controller.floor===6&&window.liftStudio.controller.state==='open',null,{timeout:30000});
assert.equal(await page.evaluate(()=>window.liftStudio.view.car.position.y),3.5);
await page.locator('#obstruction').click();await page.locator('#close-door').click();assert.equal(await page.evaluate(()=>window.liftStudio.controller.state),'open');
await page.locator('#obstruction').click();await page.locator('#alarm').click();assert.equal(await page.evaluate(()=>window.liftStudio.controller.alarm),true);
await page.locator('#reset').click();await page.locator('[data-view="lobby"]').click();
await page.setViewportSize({width:390,height:844});await page.screenshot({path:'../outputs/App_Mobile.png',fullPage:true});
assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'horizontal overflow');
console.log(JSON.stringify({status:'PASS',errors,model:await page.evaluate(()=>({ready:window.liftStudio.modelReady,doorCount:window.liftStudio.view.doors.length,landings:window.liftStudio.view.landings.length}))}));
const geometry=await page.evaluate(()=>{
 const v=window.liftStudio.view,c=window.liftStudio.controller;const results=[];
 for(const floor of [0,14]){c.position=floor*3.5;c.floor=floor;v.update(c);v.model.updateMatrixWorld(true);results.push({floor,weightY:v.weight.position.y,ropeLengths:v.ropes.map(r=>r.o.scale.y)});}
 c.reset();v.update(c);return {ropes:v.ropes.length,results};
});
assert.equal(geometry.ropes,8);for(const r of geometry.results){assert.ok(r.weightY+32.25<34.9);assert.ok(r.weightY+29.76>-19);assert.ok(r.ropeLengths.every(x=>x>0));}
console.log(JSON.stringify({geometry}));assert.deepEqual(errors,[]);await browser.close();
