import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://localhost:4173/');await page.waitForFunction(()=>window.liftStudio?.modelReady,null,{timeout:90000});
 // Software WebGL in CI: lower pixel density while retaining real input and animation.
 await page.evaluate(()=>window.liftStudio.view.renderer.setPixelRatio(.5));
 await page.locator('#game-toggle').click();assert.equal(await page.evaluate(()=>window.liftStudio.game.active),true);
 await page.waitForTimeout(400);await page.screenshot({path:'../outputs/Game_Mode_Lobby.png',fullPage:true});
 async function dragLook(dx,dy){
  while(Math.abs(dx)>.1||Math.abs(dy)>.1){const r=await page.locator('#scene').boundingBox();const cx=r.x+r.width/2,cy=r.y+r.height/2;const sx=Math.max(-r.width*.3,Math.min(r.width*.3,dx)),sy=Math.max(-r.height*.3,Math.min(r.height*.3,dy));await page.mouse.move(cx,cy);await page.mouse.down({button:'right'});await page.mouse.move(cx+sx,cy+sy);await page.mouse.up({button:'right'});dx-=sx;dy-=sy;}
 }
 async function facePoint(x,y,z){const delta=await page.evaluate(({x,y,z})=>{const p=window.liftStudio.game.player,c=window.liftStudio.controller;const dx=x-p.x,dz=z-p.z,dy=y-p.eyeY(c);const yaw=Math.atan2(-dx,-dz),pitch=Math.atan2(dy,Math.hypot(dx,dz));let angle=yaw-p.yaw;while(angle>Math.PI)angle-=2*Math.PI;while(angle< -Math.PI)angle+=2*Math.PI;return {dx:-angle/.0025,dy:-(pitch-p.pitch)/.0025};},{x,y,z});await dragLook(delta.dx,delta.dy);}
 async function clickModel(action,floor,direction){
  const target=await page.evaluate(({action,floor,direction})=>{const v=window.liftStudio.view;const o=v.pickables.find(o=>o.userData.action===action&&(floor===undefined||o.userData.floorIndex===floor)&&(direction===undefined||o.userData.direction===direction));if(!o)throw Error('button not found');v.scene.updateMatrixWorld(true);return o.getWorldPosition(v.camera.position.clone()).toArray();},{action,floor,direction});
  await facePoint(...target);
  const point=await page.evaluate(({action,floor,direction})=>{const v=window.liftStudio.view;const o=v.pickables.find(o=>o.userData.action===action&&(floor===undefined||o.userData.floorIndex===floor)&&(direction===undefined||o.userData.direction===direction));const p=o.getWorldPosition(v.camera.position.clone()).project(v.camera),r=v.canvas.getBoundingClientRect();const picked=v.getInteraction({x:p.x,y:p.y},1.8);return {x:r.x+(p.x+1)*r.width/2,y:r.y+(1-p.y)*r.height/2,picked:picked?.userData};},{action,floor,direction});
  assert.ok(point.picked,`not reachable: ${JSON.stringify({action,floor,direction,point})}`);await page.mouse.click(point.x,point.y);
 }
 // Closed doors stop real keyboard walking.
 await page.keyboard.down('w');await page.waitForTimeout(1300);await page.keyboard.up('w');
 assert.equal(await page.evaluate(()=>window.liftStudio.game.player.zone),'lobby');assert.ok(await page.evaluate(()=>window.liftStudio.game.player.z>=1.4-1e-6));
 await clickModel('hall',5,1);await page.waitForFunction(()=>window.liftStudio.controller.state==='open',null,{timeout:30000});
 await facePoint(0,1.65,-1);await page.keyboard.down('w');await page.waitForFunction(()=>window.liftStudio.game.player.zone==='cabin'&&window.liftStudio.game.player.z<-.25,null,{timeout:30000});await page.keyboard.up('w');
 assert.equal(await page.evaluate(()=>window.liftStudio.game.player.zone),'cabin');
 // Face and click the actual 3D destination buttons, not the observer panel.
 await clickModel('car',6);await clickModel('car',7);
 await page.screenshot({path:'../outputs/Game_Mode_Cabin.png',fullPage:true});
 assert.deepEqual(await page.evaluate(()=>[...window.liftStudio.controller.car]),[6,7]);console.log('boarded and selected 2F/3F');
 await page.waitForFunction(()=>window.liftStudio.controller.floor===6&&window.liftStudio.controller.state==='open',null,{timeout:180000});
 assert.equal(await page.evaluate(()=>window.liftStudio.game.player.floor),6);assert.equal(await page.evaluate(()=>window.liftStudio.game.player.eyeY(window.liftStudio.controller)),5.15);
 await facePoint(0,5.15,3.2);await page.keyboard.down('w');await page.waitForFunction(()=>window.liftStudio.game.player.zone==='lobby'&&window.liftStudio.game.player.z>1.6,null,{timeout:30000});await page.keyboard.up('w');
 await page.waitForFunction(()=>window.liftStudio.controller.floor===7&&window.liftStudio.controller.state==='open',null,{timeout:180000});
 assert.equal(await page.evaluate(()=>window.liftStudio.game.player.floor),6);assert.equal(await page.evaluate(()=>window.liftStudio.game.player.eyeY(window.liftStudio.controller)),5.15);
 // Blur releases movement and mode exit restores OrbitControls.
 await page.keyboard.down('a');await page.evaluate(()=>window.dispatchEvent(new Event('blur')));assert.equal(await page.evaluate(()=>window.liftStudio.game.keys.size),0);await page.keyboard.up('a');
 await page.locator('#game-exit').click();assert.equal(await page.evaluate(()=>window.liftStudio.game.active),false);assert.equal(await page.evaluate(()=>window.liftStudio.view.controls.enabled),true);
 assert.equal(await page.evaluate(()=>window.liftStudio.controller.obstructionSources.has('player')),false);
 await page.screenshot({path:'../outputs/Game_Mode_After_Exit.png',fullPage:true});assert.deepEqual(errors,[]);console.log('PASS: WASD, physical hall and car clicks, boarding, 2F exit, car continues to 3F while player stays, blur and observer restoration.');
}finally{await browser.close();}
