import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try {
 const page=await browser.newPage({viewport:{width:1280,height:960}});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://localhost:4173/');
 await page.waitForFunction(()=>window.liftStudio?.modelReady&&window.liftStudio.version==='1.0.1',null,{timeout:60000});
 for(const reverse of [false,true]){
  await page.locator('#reset').click();await page.locator('#time-scale').selectOption('4');
  const order=reverse?['B1층 하행 호출','9층 상행 호출']:['9층 상행 호출','B1층 하행 호출'];
  for(const name of order)await page.getByRole('button',{name,exact:true}).click();
  await page.evaluate(()=>{
   const c=window.liftStudio.controller;
   for(let i=0;i<120*180;i++){c.tick(1/120);if(c.stops.length>=2&&c.pending().length===0&&c.state==='idle')break;}
  });
  await page.waitForFunction(()=>window.liftStudio.controller.stops.length>=2&&window.liftStudio.controller.pending().length===0&&window.liftStudio.controller.state==='idle',null,{timeout:60000});
  assert.deepEqual(await page.evaluate(()=>window.liftStudio.controller.stops),reverse?[4,13]:[13,4]);
  await page.waitForFunction(()=>document.querySelector('#queue').textContent==='등록된 호출이 없습니다.');
  for(const name of order)assert.equal(await page.getByRole('button',{name,exact:true}).getAttribute('aria-pressed'),'false');
  assert.equal(await page.locator('#queue').innerText(),'등록된 호출이 없습니다.');
  console.log(JSON.stringify({reverse,state:await page.evaluate(()=>window.liftStudio.controller.snapshot())}));
 }
 await page.evaluate(()=>{for(let i=0;i<120*60;i++)window.liftStudio.controller.tick(1/120);});
 await page.waitForTimeout(300);
 assert.deepEqual(await page.evaluate(()=>window.liftStudio.controller.stops),[4,13]);
 assert.equal(await page.evaluate(()=>window.liftStudio.controller.state),'idle');
 assert.deepEqual(errors,[]);
 await page.screenshot({path:'../outputs/Hall_Call_Fix_Verified.png',fullPage:true});
 console.log('PASS: actual UI calls cleared in both input orders; idle remains stable.');
}finally{await browser.close();}
