import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {LiftScene} from '../src/scene.js';
import {WalkingPlayer} from '../src/player.js';
function scene(){
 const v=Object.create(LiftScene.prototype);v.scene=new THREE.Scene();v.ready=true;v.view='game';v.game={active:true,player:new WalkingPlayer()};v.game.player.zone='cabin';
 for(const name of ['car','cabinet','weight'])v[name]=new THREE.Group();v.parts=[];
 v.landings=Array.from({length:15},(_,floorIndex)=>{const o=new THREE.Group();o.userData.floorIndex=floorIndex;return o;});
 v.makeGameRoom();return v;
}
test('adjacent landing stays visible across a floor indicator change',()=>{
 const v=scene();v.game.player.floor=5;v.applyVisibility({floor:5,position:5.49*3.5});assert.equal(v.landings[6].visible,true);
 v.game.player.floor=6;v.applyVisibility({floor:6,position:5.51*3.5});assert.equal(v.landings[5].visible,true);
});
test('lobby geometry never teleports when a passenger changes floor',()=>{
 const v=scene();v.game.player.floor=5;v.applyVisibility({floor:5,position:5.49*3.5});const before=v.gameRoom.position.y;
 v.game.player.floor=6;v.applyVisibility({floor:6,position:5.51*3.5});assert.equal(v.gameRoom.position.y,before);
});
test('waiting player keeps their landing even while car travels away',()=>{
 const v=scene();v.game.player.zone='lobby';v.game.player.floor=5;v.applyVisibility({floor:14,position:49});assert.equal(v.landings[5].visible,true);assert.equal(v.landings[14].visible,false);
});
