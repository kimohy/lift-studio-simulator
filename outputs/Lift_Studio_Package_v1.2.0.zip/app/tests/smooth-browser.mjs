import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try {
 const page=await browser.newPage({viewport:{width:1200,height:900}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://localhost:4173');await page.waitForFunction(()=>window.liftStudio?.modelReady,null,{timeout:90000});await page.locator('#game-toggle').click();
 const result=await page.evaluate(()=>{
  const {controller:c,view:v,game:g}=window.liftStudio;c.paused=true;g.player.zone='cabin';g.player.x=0;g.player.z=-.3;g.player.yaw=Math.PI;g.player.pitch=0;
  const rows=[];
  for(let n=0;n<=60;n++){c.position=(5.4+n/300)*3.5;c.floor=Math.round(c.position/3.5);c.velocity=1;c.state='moving';g.update(0);v.update(c);
   rows.push({camera:v.camera.position.y,relative:v.camera.position.y-v.car.position.y,roomY:v.gameRoom.position.y,roomPositions:v.gameRoom.children.map(r=>r.position.y),near:v.landings.filter(o=>[5,6].includes(o.userData.floorIndex)).every(o=>o.visible)});
  }v.render();return rows;
 });
 assert.ok(result.every(r=>r.near&&r.roomY===0));assert.ok(result.every(r=>Math.abs(r.relative-result[0].relative)<1e-10));
 for(let i=1;i<result.length;i++){assert.ok(Math.abs(result[i].camera-result[i-1].camera-3.5/300)<1e-10);assert.deepEqual(result[i].roomPositions,result[0].roomPositions);}
 await page.screenshot({path:'../outputs/Smooth_Floor_Travel.png',fullPage:true});assert.deepEqual(errors,[]);console.log('PASS: 61 boundary samples; continuous camera/car offset, fixed lobby heights, both nearby landings retained, no browser errors.');
} finally {await browser.close();}
