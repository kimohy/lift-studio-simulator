import {chromium} from 'playwright';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1050}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.voiceCalls=[];window.voiceCancels=0;class U{constructor(text){this.text=text;}}
  Object.defineProperty(window,'SpeechSynthesisUtterance',{value:U});Object.defineProperty(window,'speechSynthesis',{value:{getVoices:()=>[{lang:'ko-KR',name:'Korean Natural'},{lang:'en-US',name:'English Natural'}],cancel(){window.voiceCancels++;},speak(u){window.voiceCalls.push({text:u.text,lang:u.lang,volume:u.volume});setTimeout(()=>u.onend?.(),15);}}});
 });
 await page.goto('http://localhost:4173');await page.waitForFunction(()=>window.liftStudio?.modelReady,null,{timeout:90000});
 await page.evaluate(()=>{window.liftStudio.view.renderer.setPixelRatio(.5);window.liftStudio.announcer.gap=0;});
 await page.locator('#sound').click();await page.waitForFunction(()=>window.voiceCalls.some(x=>x.text==='Welcome aboard.'));
 assert.equal(await page.locator('#voice-panel').isVisible(),true);
 await page.getByRole('button',{name:'2층 목적지',exact:true}).click();await page.waitForFunction(()=>window.voiceCalls.some(x=>x.text==='Going up.'));
 await page.evaluate(()=>{const {controller:c,announcer:a}=window.liftStudio;for(let i=0;i<1800&&c.state!=='opening';i++){c.tick(1/60);a.observe(c);}});
 await page.waitForFunction(()=>window.voiceCalls.some(x=>x.text==='The door is opening.'));
 assert.match(await page.locator('#voice-ko').textContent(),/2층/);assert.match(await page.locator('#voice-en').textContent(),/Second floor/);
 await page.screenshot({path:'../outputs/Hotel_Voice_Guide.png',fullPage:true});
 await page.locator('#close-door').click();await page.waitForFunction(()=>window.voiceCalls.some(x=>x.text==='The door is closing.'));
 await page.locator('#obstruction').click();await page.waitForFunction(()=>window.voiceCalls.some(x=>x.text.includes('Please stand clear.')));
 await page.locator('#voice-volume').fill('35');assert.equal(await page.evaluate(()=>window.liftStudio.announcer.volume),.35);
 await page.locator('#pause').click();assert.equal(await page.evaluate(()=>window.liftStudio.announcer.active),null);
 await page.locator('#reset').click();assert.equal(await page.evaluate(()=>window.liftStudio.controller.doorCloseSeconds),5);
 await page.locator('#sound').click();assert.equal(await page.locator('#voice-panel').isVisible(),false);assert.equal(await page.evaluate(()=>window.liftStudio.controller.doorCloseSeconds),1.7);
 assert.deepEqual(errors,[]);console.log('PASS: voice toggle, KO/EN callbacks, upward movement, floor arrival, doors, obstruction reopening, volume, pause, reset and mute. Speech adapter simulated; physical speaker quality is device-dependent.');
}finally{await browser.close();}
